// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  apiKey:'b73aedf9955c4dc2aa525e6f94d88495',
  apiUrl:'https://newsapi.org/v2',
   firebaseConfig : {
    apiKey: "AIzaSyDRt5h5STMJmWHQ3VuqMHB11ARcDLFrKlQ",
    authDomain: "newshubs-fb76a.firebaseapp.com",
    projectId: "newshubs-fb76a",
    storageBucket: "newshubs-fb76a.appspot.com",
    messagingSenderId: "710324357956",
    appId: "1:710324357956:web:ac25021672e23480766511"
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
