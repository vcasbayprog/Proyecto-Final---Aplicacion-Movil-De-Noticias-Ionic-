export const environment = {
  production: true,
  apiKey:'b73aedf9955c4dc2aa525e6f94d88495',
  apiUrl:'https://newsapi.org/v2',
  firebaseConfig : {
    apiKey: "AIzaSyDRt5h5STMJmWHQ3VuqMHB11ARcDLFrKlQ",
    authDomain: "newshubs-fb76a.firebaseapp.com",
    projectId: "newshubs-fb76a",
    storageBucket: "newshubs-fb76a.appspot.com",
    messagingSenderId: "710324357956",
    appId: "1:710324357956:web:ac25021672e23480766511"
  },
};
